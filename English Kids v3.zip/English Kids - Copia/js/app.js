// CONSTANTES E ESTADO INICIAL
const STORAGE = 'duokids_final_v1'; // Chave para armazenamento local

// Estado global da aplicação
let state = {
  user: null,     // Dados do usuário logado
  xp: 0,          // Pontos de experiência
  stars: 0,       // Estrelas conquistadas
  progress: {},    // Progresso nas lições (lessonId: stars)
  mission: 0,      // Progresso na missão diária
  classes: []      // Turmas (apenas para professores)
};

// LISTA COMPLETA DE LIÇÕES (mantida integralmente)
const LESSONS = [
  {
    id: 'l1', title: 'Greetings', level: 'Iniciante',
    vocab: [{en:'Hello',pt:'Olá'}, {en:'Good morning',pt:'Bom dia'}, {en:'Bye',pt:'Tchau'}],
    content: 'Nesta lição você aprende formas básicas de cumprimento. Pratique dizendo as palavras e reconhecendo suas traduções.',
    exercises: [
      {type:'mcq', q:'Qual a tradução de "Hello"?', options:['Tchau','Olá','Bom dia'], answer:'Olá'},
      {type:'fill', q:'Complete: Good ____', answer:'morning'}
    ]
  },
  { id:'l2', title:'Colors', level:'Iniciante', vocab:[{en:'Red',pt:'Vermelho'},{en:'Blue',pt:'Azul'},{en:'Green',pt:'Verde'}], content:'Cores básicas em inglês.', exercises:[{type:'mcq', q:'Qual a tradução de "Red"?', options:['Azul','Vermelho','Verde'], answer:'Vermelho'},{type:'fill', q:'Complete: The sky is ____', answer:'blue'}] },
  { id:'l3', title:'Animals', level:'Iniciante', vocab:[{en:'Cat',pt:'Gato'},{en:'Dog',pt:'Cachorro'},{en:'Bird',pt:'Pássaro'}], content:'Animais comuns.', exercises:[{type:'mcq', q:'Qual a tradução de "Dog"?', options:['Gato','Cachorro','Pássaro'], answer:'Cachorro'},{type:'match', q:'Combine: Cat, Dog', pairs:[['Cat','Gato'], ['Dog','Cachorro']]}] },
  { id:'l4', title:'Food', level:'Iniciante', vocab:[{en:'Apple',pt:'Maçã'},{en:'Banana',pt:'Banana'},{en:'Milk',pt:'Leite'}], content:'Palavras de comida.', exercises:[{type:'mcq', q:'Qual a tradução de "Apple"?', options:['Banana','Maçã','Leite'], answer:'Maçã'},{type:'fill', q:'Complete: I like ____', answer:'apple'}] },
  { id:'l5', title:'Family', level:'Iniciante', vocab:[{en:'Mother',pt:'Mãe'},{en:'Father',pt:'Pai'},{en:'Brother',pt:'Irmão'}], content:'Palavras de família.', exercises:[{type:'mcq', q:'Qual a tradução de "Mother"?', options:['Pai','Mãe','Irmão'], answer:'Mãe'},{type:'match', q:'Combine: Mother, Father', pairs:[['Mother','Mãe'], ['Father','Pai']]}] }
];

// UTILITÁRIOS (mantidos exatamente como estavam)
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

// Toca efeitos sonoros
function playSound(name){ 
  const map = {
    click:'assets/sounds/click.wav', 
    win:'assets/sounds/win.wav', 
    wrong:'assets/sounds/wrong.wav'
  }; 
  const a = new Audio(map[name]||map.click); 
  a.volume = 0.8; 
  try{ a.play(); }catch(e){} 
}

// PERSISTÊNCIA DO ESTADO (original)
function loadState(){ 
  try{ 
    const raw = localStorage.getItem(STORAGE); 
    if(raw) state = JSON.parse(raw); 
  }catch(e){ console.warn(e);} 
}

function saveState(){ 
  localStorage.setItem(STORAGE, JSON.stringify(state)); 
}

// INICIALIZAÇÃO DA APLICAÇÃO (original, apenas com comentários)
function init(){
  // Configura abas de login/cadastro
  $('#tabSignIn').addEventListener('click', ()=>{ 
    $('#tabSignIn').classList.add('active'); 
    $('#tabSignUp').classList.remove('active'); 
    $('#signinForm').style.display='block'; 
    $('#signupForm').style.display='none'; 
  });
  
  $('#tabSignUp').addEventListener('click', ()=>{ 
    $('#tabSignUp').classList.add('active'); 
    $('#tabSignIn').classList.remove('active'); 
    $('#signupForm').style.display='block'; 
    $('#signinForm').style.display='none'; 
  });

  // Cadastro de novo usuário (com tratamento de foto)
  $('#btnSignUp').addEventListener('click', (e)=>{
    e.preventDefault();
    const name = $('#signupName').value.trim();
    const dob = $('#signupDob').value;
    const role = $('#signupRole').value;
    const photoInput = $('#signupPhoto');
    
    if(!name){ alert('Digite um nome'); return; }
    
    const reader = () => {
      const user = { name, dob, role, photo: null };
      state = Object.assign({}, state, { user, xp:0, stars:0, progress:{}, mission:0 });
      saveState(); 
      showApp();
    };
    
    if(photoInput.files && photoInput.files[0]){
      const f = photoInput.files[0];
      const r = new FileReader();
      r.onload = function(ev){ 
        const user = { name, dob, role, photo: ev.target.result }; 
        state = { ...state, user, xp:0, stars:0, progress:{}, mission:0 }; 
        saveState(); 
        showApp(); 
      }
      r.readAsDataURL(f);
    } else {
      reader();
    }
  });

  // Login simplificado
  $('#btnSignIn').addEventListener('click', (e)=>{
    e.preventDefault();
    const name = $('#signinName').value.trim();
    const role = $('#signinRole').value;
    if(!name){ alert('Digite seu nome'); return; }
    
    // Tenta carregar usuário existente
    const raw = localStorage.getItem(STORAGE);
    if(raw){ 
      try{ 
        const s = JSON.parse(raw); 
        if(s.user && s.user.name === name){ 
          state = s; 
          showApp(); 
          return; 
        } 
      }catch(e){} 
    }
    
    // Cria novo usuário
    state = { ...state, user: { name, role, photo:null }, xp:0, stars:0, progress:{}, mission:0 };
    saveState(); 
    showApp();
  });

  // Configura navegação principal
  $$('.navbtn').forEach(btn => btn.addEventListener('click', (e)=>{ 
    const v = e.currentTarget.dataset.view; 
    switchView(v); 
    playSound('click'); 
  }));

  // Botões de ação rápida
  $('#gotoLessons').addEventListener('click', ()=>{ switchView('lessons'); playSound('click'); });
  $('#gotoGames').addEventListener('click', ()=>{ switchView('games'); playSound('click'); });
  $('#logoutBtn').addEventListener('click', ()=>{ 
    if(confirm('Sair da conta?')){ 
      localStorage.removeItem(STORAGE); 
      location.reload(); 
    } 
  });

  // Gerenciamento de perfil
  $('#saveProfile').addEventListener('click', (e)=>{
    e.preventDefault();
    const name = $('#profileName').value.trim();
    const dob = $('#profileDob').value;
    const hobbies = $('#profileHobbies').value.trim();
    const bio = $('#profileBio').value.trim();
    const photoInput = $('#profilePhoto');
    
    if(photoInput.files && photoInput.files[0]){
      const r = new FileReader();
      r.onload = function(ev){ 
        state.user.photo = ev.target.result; 
        finishProfileSave(name, dob, hobbies, bio); 
      }
      r.readAsDataURL(photoInput.files[0]);
    } else {
      finishProfileSave(name, dob, hobbies, bio);
    }
  });
  
  // Reset de progresso
  $('#resetProgress').addEventListener('click', ()=>{ 
    if(confirm('Resetar progresso?')){ 
      state.xp = 0; 
      state.stars = 0; 
      state.progress = {}; 
      saveState(); 
      renderApp(); 
      alert('Progresso resetado'); 
    } 
  });

  // Controles de turmas (professor)
  $('#createClassBtn').addEventListener('click', (e)=>{
    e.preventDefault();
    createClass();
  });

  // Carrega estado inicial
  loadState();
  if(state && state.user && state.user.name){ 
    showApp(); 
  } else { 
    $('#loginView').style.display='block'; 
  }
}

/* ========== FUNÇÕES DA APLICAÇÃO ========== */

// Mostra a aplicação principal após login
function showApp(){
  $('#loginView').style.display='none';
  $('#app').style.display='block';
  renderApp();
  switchView('home');
}

// Atualiza toda a UI da aplicação
function renderApp(){
  // Mostra/oculta navegação para professores
  if(state.user && state.user.role === 'teacher'){
    $('#navClasses').style.display = 'inline-flex';
  } else {
    $('#navClasses').style.display = 'none';
  }

  // Atualiza dados do usuário
  if(state.user){
    $('#userName').textContent = state.user.name || 'Aluno';
    $('#userRole').textContent = state.user.role === 'teacher' ? 'Professor' : 'Aluno';
    $('#xpCount').textContent = state.xp || 0;
    $('#starsCount').textContent = '🌟 ' + (state.stars || 0);
    
    // Configura avatar (imagem ou ícone)
    $('#profileAvatar').textContent = state.user.photo ? '' : (state.user.name ? state.user.name.charAt(0).toUpperCase() : '👦');
    if(state.user.photo){
      $('#profileAvatar').style.backgroundImage = `url(${state.user.photo})`;
      $('#profileAvatar').style.backgroundSize = 'cover';
      $('#profileAvatar').textContent = '';
    } else {
      $('#profileAvatar').style.backgroundImage = '';
    }
  }
  
  // Renderiza seções dinâmicas
  renderLessonList();
  renderRecentLessons();
  renderGamesList();
  renderProfilePreview();
  renderClassesList();
  saveState();
}

// Renderiza a lista de lições disponíveis
function renderLessonList(){
  const el = $('#lessonList'); 
  el.innerHTML = '';
  
  LESSONS.forEach(l => {
    const div = document.createElement('div'); 
    div.className = 'lesson-card';
    div.innerHTML = `
      <h3>${l.title}</h3>
      <div class="muted">${l.level}</div>
      <p class="small muted">${l.content.slice(0,120)}...</p>
      <div class="row" style="margin-top:8px">
        <button class="btn openLesson" data-id="${l.id}">Abrir</button>
        <button class="btn secondary startLesson" data-id="${l.id}">Fazer</button>
      </div>
    `;
    el.appendChild(div);
  });
  
  // Adiciona listeners aos botões
  $$('.openLesson').forEach(b => b.addEventListener('click', e => openLesson(e.target.dataset.id)));
  $$('.startLesson').forEach(b => b.addEventListener('click', e => startLesson(e.target.dataset.id)));
}

// Renderiza lições recentes na página inicial
function renderRecentLessons(){
  const el = $('#recentLessons'); 
  el.innerHTML='';
  
  // Mostra as 3 primeiras lições como "recentes"
  LESSONS.slice(0,3).forEach(l => {
    const card = document.createElement('div'); 
    card.className = 'card small'; 
    card.style.padding='10px'; 
    card.style.minWidth='180px';
    card.innerHTML = `
      <strong>${l.title}</strong>
      <div class="muted small">${l.vocab.map(v => v.en).join(', ')}</div>
    `;
    el.appendChild(card);
  });
}

// Abre uma lição específica para visualização
function openLesson(id){
  const lesson = LESSONS.find(x=>x.id===id);
  const cont = $('#lessonContent'); 
  cont.innerHTML='';
  
  // Cria estrutura da lição
  const card = document.createElement('div'); 
  card.className='card'; 
  card.innerHTML = `
    <h3>${lesson.title} — ${lesson.level}</h3>
    <p>${lesson.content}</p>
    <h4>Vocabulário</h4>
    <div id="vocabList"></div>
    <h4>Exercícios</h4>
    <div id="exerciseArea"></div>
    <div style="margin-top:10px" class="row">
      <button class="btn" id="completeLesson">Marcar como completo</button>
    </div>
  `;
  cont.appendChild(card);

  // Preenche vocabulário
  const vocab = card.querySelector('#vocabList');
  lesson.vocab.forEach(v => { 
    const d = document.createElement('div'); 
    d.innerHTML = `<strong>${v.en}</strong> — <span class="muted">${v.pt}</span>`; 
    vocab.appendChild(d); 
  });

  // Renderiza exercícios
  const ex = card.querySelector('#exerciseArea');
  lesson.exercises.forEach((exer, idx) => {
    const wrap = document.createElement('div'); 
    wrap.className='card small'; 
    wrap.style.marginTop='8px';
    
    // Exercício múltipla escolha
    if(exer.type==='mcq'){
      wrap.innerHTML = `<div><strong>${exer.q}</strong></div>`;
      exer.options.forEach(opt => { 
        const b=document.createElement('button'); 
        b.className='btn secondary option'; 
        b.textContent = opt; 
        b.dataset.answer = exer.answer; 
        wrap.appendChild(b); 
        b.addEventListener('click', (e)=>{
          if(e.target.textContent === exer.answer){
            playSound('win'); 
            alert('Resposta correta!'); 
            state.xp += 5; 
            state.stars += 1; 
            saveState(); 
            renderApp(); 
          } else { 
            playSound('wrong'); 
            alert('Resposta incorreta!'); 
          } 
        }); 
      });
    } 
    // Exercício preenchimento
    else if(exer.type==='fill'){
      wrap.innerHTML = `
        <div><strong>${exer.q}</strong></div>
        <input class="form-input" placeholder="Digite aqui"> 
        <button class="btn submitFill">Enviar</button>
      `;
      wrap.querySelector('.submitFill').addEventListener('click', ()=>{
        const val = wrap.querySelector('input').value.trim().toLowerCase();
        if(val === exer.answer.toLowerCase()){
          playSound('win'); 
          alert('Muito bem!'); 
          state.xp += 6; 
          state.stars += 1; 
          saveState(); 
          renderApp(); 
        } else { 
          playSound('wrong'); 
          alert('Tente novamente'); 
        } 
      });
    } 
    // Exercício de correspondência
    else if(exer.type==='match'){
      wrap.innerHTML = `
        <div><strong>${exer.q}</strong></div>
        <div class="muted small">Clique nas correspondências</div>
        <div class="matchArea" style="display:flex;gap:8px;margin-top:6px"></div>
      `;
      const area = wrap.querySelector('.matchArea');
      const left = exer.pairs.map(p=>p[0]); 
      const right = exer.pairs.map(p=>p[1]);
      
      // Cria botões para os pares
      left.forEach(item => { 
        const b = document.createElement('button'); 
        b.className='btn secondary left'; 
        b.textContent = item; 
        area.appendChild(b); 
      });
      right.forEach(item => { 
        const b = document.createElement('button'); 
        b.className='btn secondary right'; 
        b.textContent = item; 
        area.appendChild(b); 
      });
      
      // Lógica de verificação de pares
      let selLeft = null;
      area.addEventListener('click', (ev)=>{
        const t = ev.target; 
        if(t.classList.contains('left')){ 
          selLeft = t.textContent; 
          t.style.outline='3px solid rgba(255,107,107,0.25)'; 
        }
        if(t.classList.contains('right') && selLeft){ 
          const pair = exer.pairs.find(p=>p[0]===selLeft && p[1]===t.textContent); 
          if(pair){ 
            playSound('win'); 
            alert('Par correto!'); 
            state.xp += 6; 
            state.stars += 1; 
            saveState(); 
            renderApp(); 
          } else { 
            playSound('wrong'); 
            alert('Não é par'); 
          } 
          selLeft = null; 
          $$('.matchArea .left').forEach(x=>x.style.outline=''); 
        }
      });
    }
    ex.appendChild(wrap);
  });

  // Botão para marcar lição como completa
  card.querySelector('#completeLesson').addEventListener('click', ()=>{
    state.progress[id] = Math.max(state.progress[id]||0, 1);
    state.stars += 1; 
    state.xp += 10; 
    state.mission += 1; 
    saveState(); 
    renderApp(); 
    alert('Lição marcada como completa!'); 
  });
  
  // Rolagem suave para o conteúdo
  cont.scrollIntoView({behavior:'smooth'});
}

// Inicia uma lição (atalho para openLesson com feedback sonoro)
function startLesson(id){
  openLesson(id);
  playSound('click');
}

/* ========== GERENCIAMENTO DE TURMAS (PROFESSOR) ========== */

// Cria uma nova turma
function createClass(){
  const name = $('#newClassName').value.trim();
  const level = $('#newClassLevel').value;
  if(!name){ alert('Digite o nome da turma'); return; }
  
  const newClass = {
    id: 'c' + Date.now(),
    name,
    level,
    students: []
  };
  
  state.classes.push(newClass);
  saveState();
  renderClassesList();
  $('#newClassName').value = '';
  alert('Turma criada!');
}

// Renderiza a lista de turmas
function renderClassesList(){
  const el = $('#classesList'); 
  if(!el) return;
  el.innerHTML = '';
  
  // Verificação de perfil professor
  if(!state.user || state.user.role !== 'teacher'){
    el.innerHTML = '<div class="muted">Área disponível apenas para professores.</div>';
    return;
  }
  
  if(state.classes.length === 0){
    el.innerHTML = '<div class="muted">Nenhuma turma criada ainda.</div>';
    return;
  }
  
  // Renderiza cada turma
  state.classes.forEach(klass => {
    const card = document.createElement('div'); 
    card.className = 'card small'; 
    card.style.marginBottom='8px';
    
    const studentsCount = klass.students.length;
    const totalXP = klass.students.reduce((s,st)=> s + (st.xp||0), 0);
    const avgXP = studentsCount ? Math.round(totalXP / studentsCount) : 0;
    const totalStars = klass.students.reduce((s,st)=> s + (st.stars||0), 0);
    
    card.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <strong>${klass.name}</strong>
          <div class="muted small">${klass.level} • ${studentsCount} aluno(s)</div>
        </div>
        <div class="row">
          <button class="btn viewClass" data-id="${klass.id}">Abrir</button>
          <button class="btn secondary deleteClass" data-id="${klass.id}">Excluir</button>
        </div>
      </div>
      <div class="muted small" style="margin-top:8px">
        Média XP: ${avgXP} • Estrelas totais: ${totalStars}
      </div>
    `;
    el.appendChild(card);
  });
  
  // Adiciona listeners
  $$('.viewClass').forEach(b => b.addEventListener('click', e => openClass(e.target.dataset.id)));
  $$('.deleteClass').forEach(b => b.addEventListener('click', e => {
    const id = e.target.dataset.id;
    if(confirm('Excluir turma? Esta ação removerá os alunos desta turma localmente.')){ 
      state.classes = state.classes.filter(c=>c.id!==id); 
      saveState(); 
      renderClassesList(); 
      $('#classDetail').innerHTML=''; 
      alert('Turma excluída'); 
    }
  }));
}

// Abre os detalhes de uma turma específica
function openClass(classId){
  const klass = state.classes.find(c=>c.id===classId);
  if(!klass) return;
  
  const detail = $('#classDetail'); 
  detail.innerHTML = '';
  const wrapper = document.createElement('div'); 
  wrapper.className='card';
  
  // Estrutura do painel de turma
  wrapper.innerHTML = `
    <h3>${klass.name} — ${klass.level}</h3>
    <div class="muted small">Alunos: ${klass.students.length}</div>
    <div style="margin-top:10px" id="studentsArea"></div>
    <div style="margin-top:12px">
      <h4>Adicionar aluno</h4>
      <div class="form">
        <input id="newStudentName" placeholder="Nome do aluno">
        <div class="row"><button id="addStudentBtn" class="btn">Adicionar</button></div>
      </div>
    </div>
    <div style="margin-top:12px" id="classActions"></div>
  `;
  detail.appendChild(wrapper);

  // Renderiza a lista de alunos
  function renderStudents(){
    const sa = wrapper.querySelector('#studentsArea'); 
    sa.innerHTML = '';
    
    if(klass.students.length === 0){ 
      sa.innerHTML = '<div class="muted">Nenhum aluno ainda.</div>'; 
      return; 
    }
    
    klass.students.forEach(s => {
      const sdiv = document.createElement('div'); 
      sdiv.className = 'card small'; 
      sdiv.style.marginBottom='6px';
      
      // Calcula lições completas
      const completed = Object.keys(s.progress || {}).length;
      
      sdiv.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div>
            <strong>${s.name}</strong>
            <div class="muted small">
              XP: ${s.xp || 0} • ⭐ ${s.stars || 0} • Lições completas: ${completed}
            </div>
          </div>
          <div class="row">
            <button class="btn viewStudent" data-class="${klass.id}" data-student="${s.id}">Ver</button>
            <button class="btn secondary removeStudent" data-class="${klass.id}" data-student="${s.id}">Remover</button>
          </div>
        </div>
      `;
      sa.appendChild(sdiv);
    });
    
    // Listeners para os botões
    $$('.viewStudent').forEach(b => b.addEventListener('click', e => {
      viewStudentDetail(e.target.dataset.class, e.target.dataset.student);
    }));
    
    $$('.removeStudent').forEach(b => b.addEventListener('click', e => {
      if(confirm('Remover aluno da turma?')){ 
        const c = state.classes.find(x=>x.id===e.target.dataset.class); 
        c.students = c.students.filter(st=>st.id!==e.target.dataset.student); 
        saveState(); 
        renderClassesList(); 
        renderStudents(); 
      } 
    }));
  }

  // Adiciona novo aluno à turma
  wrapper.querySelector('#addStudentBtn').addEventListener('click', (ev)=>{
    ev.preventDefault();
    const name = wrapper.querySelector('#newStudentName').value.trim();
    if(!name){ alert('Digite o nome do aluno'); return; }
    
    const newStudent = { 
      id: 's' + Date.now(), 
      name, 
      xp:0, 
      stars:0, 
      progress: {} 
    };
    
    klass.students.push(newStudent);
    saveState();
    wrapper.querySelector('#newStudentName').value = '';
    renderClassesList();
    renderStudents();
    alert('Aluno adicionado!');
  });

  // Ações da turma
  const classActions = wrapper.querySelector('#classActions');
  classActions.innerHTML = `
    <button id="markAllZero" class="btn secondary">Zerar progresso (local)</button>
  `;
  
  classActions.querySelector('#markAllZero').addEventListener('click', ()=>{
    if(confirm('Zerar progresso de todos os alunos desta turma?')){ 
      klass.students.forEach(s=>{ 
        s.xp = 0; 
        s.stars = 0; 
        s.progress = {}; 
      }); 
      saveState(); 
      renderApp(); 
      openClass(classId); 
      alert('Progresso zerado para a turma.'); 
    } 
  });

  renderStudents();
  detail.scrollIntoView({behavior:'smooth'});
}

// Mostra detalhes de um aluno específico
function viewStudentDetail(classId, studentId){
  const klass = state.classes.find(c=>c.id===classId);
  if(!klass) return;
  
  const student = klass.students.find(s=>s.id===studentId);
  if(!student) return;
  
  const detail = $('#classDetail'); 
  detail.innerHTML = '';
  const wrapper = document.createElement('div'); 
  wrapper.className='card';
  
  // Gera lista de lições com status
  let listHtml = '<div class="muted small">Progresso por lição:</div>';
  LESSONS.forEach(l => {
    const done = student.progress && student.progress[l.id];
    listHtml += `
      <div style="margin-top:6px" class="card small">
        <strong>${l.title}</strong>
        <div class="muted small">${l.level}</div>
        <div>Completo: ${done ? 'Sim' : 'Não'}</div>
        <div style="margin-top:6px" class="row">
          <button class="btn markComplete" data-class="${classId}" data-student="${studentId}" data-lesson="${l.id}">
            ${done ? 'Desmarcar' : 'Marcar completo'}
          </button>
        </div>
      </div>
    `;
  });

  // Estrutura do painel do aluno
  wrapper.innerHTML = `
    <h3>${student.name}</h3>
    <div class="muted small">XP: ${student.xp || 0} • ⭐ ${student.stars || 0}</div>
    <div style="margin-top:10px">${listHtml}</div>
    <div style="margin-top:12px">
      <button id="backToClass" class="btn secondary">Voltar</button>
    </div>
  `;
  detail.appendChild(wrapper);

  // Listeners para marcar/desmarcar lições
  $$('.markComplete').forEach(b => b.addEventListener('click', (e)=>{
    const cid = e.target.dataset.class; 
    const sid = e.target.dataset.student; 
    const lid = e.target.dataset.lesson;
    
    const c = state.classes.find(x=>x.id===cid); 
    const s = c.students.find(x=>x.id===sid);
    
    if(s.progress && s.progress[lid]){ // Desmarcar
      delete s.progress[lid];
      s.xp = Math.max(0, (s.xp || 0) - 10);
      s.stars = Math.max(0, (s.stars || 0) - 1);
      alert('Marcação removida.');
    } else { // Marcar completo
      s.progress[lid] = 1;
      s.xp = (s.xp || 0) + 10;
      s.stars = (s.stars || 0) + 1;
      alert('Lição marcada como completa para o aluno.');
    }
    
    saveState();
    viewStudentDetail(cid, sid); // Recarrega
    renderClassesList();
  }));

  // Botão voltar
  wrapper.querySelector('#backToClass').addEventListener('click', ()=> 
    openClass(classId)
  );
}

// Renderiza pré-visualização do perfil
function renderProfilePreview(){
  // Preenche campos do formulário
  $('#profileName').value = state.user ? state.user.name : '';
  $('#profileDob').value = state.user ? state.user.dob || '' : '';
  $('#profileHobbies').value = state.user ? state.user.hobbies || '' : '';
  $('#profileBio').value = state.user ? state.user.bio || '' : '';
  
  const preview = $('#profilePreview'); 
  preview.innerHTML = '';
  
  if(state.user && (state.user.photo || state.user.name)){
    const d = document.createElement('div'); 
    d.className='card small'; 
    d.innerHTML = `
      <div><strong>${state.user.name}</strong></div>
      <div class="muted">${state.user.dob || ''}</div>
      <div style="margin-top:8px">${state.user.hobbies || ''}</div>
      <div style="margin-top:8px">${state.user.bio || ''}</div>
    `;
    
    if(state.user.photo){ 
      const img = document.createElement('img'); 
      img.src = state.user.photo; 
      img.style.maxWidth='120px'; 
      img.style.borderRadius='8px'; 
      d.appendChild(img); 
    }
    
    preview.appendChild(d);
  }
}

// Alterna entre views da aplicação
function switchView(v){
  // Esconde todas as views
  $$('.view').forEach(x => x.style.display = 'none');
  
  // Verificação especial para turmas (apenas professores)
  if(v === 'classes' && (!state.user || state.user.role !== 'teacher')){
    $('#view_home').style.display = 'block';
    alert('Apenas professores podem acessar Gerenciar Turmas.');
    return;
  }
  
  // Mostra a view solicitada
  $(`#view_${v}`).style.display = 'block';
  
  // Atualiza navegação ativa
  $$('.navbtn').forEach(n=> n.classList.remove('active'));
  $(`.navbtn[data-view="${v}"]`)?.classList.add('active');
}

// Finaliza o salvamento do perfil (chamado após upload de foto)
function finishProfileSave(name, dob, hobbies, bio){
  state.user.name = name || state.user.name;
  state.user.dob = dob || state.user.dob;
  state.user.hobbies = hobbies || state.user.hobbies;
  state.user.bio = bio || state.user.bio;
  saveState(); 
  renderApp(); 
  alert('Perfil salvo!');
}


init();